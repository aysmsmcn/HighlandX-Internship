# Porting Guide — moving the add-in to another device / Outlook profile

This add-in has two halves that must be set up on the new machine:

1. **The web add-in** — `server.js` serves the task pane over HTTPS at
   `https://localhost:3000`, and Outlook loads it via `manifest.json`.
2. **The briefing generator** — a scheduled task runs the Claude CLI against
   `daily-brief.md` once a day and writes `briefings/briefing-YYYY-MM-DD.md`,
   which the task pane then displays.

Both run **locally as the logged-in user**, so everything is per-device and
per-profile. Work top to bottom.

---

## What is device-/profile-specific

| Thing | Where | Action on new device |
|-------|-------|----------------------|
| Install path | `scripts/Run-DailyBriefing.ps1`, `scripts/Install-Tasks.ps1` (`$AddinRoot`), `daily-brief.md` (output path) | Update to the new absolute folder path (Step 3) |
| Person / CRM identity | `daily-brief.md` (name, Affinity email, internal domain) | Update to the new user (Step 4) |
| Node / Claude CLI / dev certs | the machine | Install + trust (Steps 1, 5, 6) |
| Claude auth + Affinity/Outlook MCP | the user's Claude config | Authenticate + register MCP (Step 6) |
| Add-in sideload | the Outlook profile | Sideload once (Step 7) |
| Scheduled tasks | Windows Task Scheduler, bound to `$env:USERNAME` | Register (Step 8) |

`server.js` itself needs **no** path edits — it resolves the briefings folder
from its own location (`__dirname`), so it is correct wherever the folder lives.

---

## Step 1 — Prerequisites

Install on the new device (per user that will run it):

- **Node.js LTS** — `node -v` should print a version. Provides `node`/`npm`.
- **Claude Code CLI** — `claude --version` should work, and `claude` must be on
  the user's PATH (the scheduled task calls it by name).
- **PowerShell 5.1+** (built into Windows) — used by the scripts.

---

## Step 2 — Copy the project

Copy the whole folder to the new device. **Do not** copy these (regenerate them
fresh — they are machine-/run-specific):

- `node_modules/` — reinstall in Step 5 (platform-specific binaries).
- `logs/` and `briefings/` — stale output from the old machine.

**Do** copy `vendor/` (the pinned `marked.min.js` / `purify.min.js`). If it's
missing, re-download with the URLs noted in `taskpane.html`.

Pick the destination path now and note it — you'll use it everywhere below. The
examples use:

```
C:\Users\<USERNAME>\Outlook Daily Synopsis
```

---

## Step 3 — Set the install path (3 places must agree)

The server reads `<folder>\briefings\`, so the generator must write to that same
folder. Three locations currently hardcode the path and **must all match the
folder you chose in Step 2**:

1. `scripts\Run-DailyBriefing.ps1` — the `$AddinRoot` default on line ~3.
2. `scripts\Install-Tasks.ps1` — the `$AddinRoot` default on line ~3.
3. `daily-brief.md` — the output path near the end ("Write the briefing to ...").

Set all three to the new absolute path (no trailing slash). Example: if the
folder is `C:\Tools\Synopsis`, then `daily-brief.md` should say
`C:\Tools\Synopsis\briefings\briefing-YYYY-MM-DD.md` and both scripts'
`$AddinRoot` default should be `C:\Tools\Synopsis`.

> Tip: instead of editing the script defaults, you can pass `-AddinRoot "<path>"`
> when you run them. But `daily-brief.md` must be edited regardless, because the
> output path inside it is what tells Claude where to write.

---

## Step 4 — Personalize the briefing prompt

`daily-brief.md` is written for one specific user. Update:

- The **person's name** (currently "Michael Lackey").
- The **Affinity / CRM email** used to scope notes (currently `mlackey@hcp.com`).
- The **internal email domain** used to decide which meetings are "external"
  (currently `hcp.com` — change to the new org's domain).

Leave the section structure and the "Affinity-only, no web" rules as-is unless
you want different briefing content.

---

## Step 5 — Install dependencies and trust the dev certificate

From the project folder:

```powershell
npm install
npx office-addin-dev-certs install
```

- `npm install` pulls `express` and the `office-addin-*` tooling.
- `office-addin-dev-certs install` creates and trusts a localhost HTTPS
  certificate **on this machine** (without it, `server.js` won't start and the
  pane can't load over HTTPS). Accept the certificate-trust prompt.

---

## Step 6 — Configure Claude auth + MCP  ⚠️ required for briefings

The scheduled task runs `claude -p` **non-interactively**, so the new user's
Claude must be able to run with no prompts AND have the data tools available:

1. **Authenticate Claude** for this user (e.g. `claude setup-token`, or sign in
   once interactively, or set `ANTHROPIC_API_KEY`). Verify with a quick headless
   call: `echo "say hi" | claude -p`.
2. **Register the Affinity and Outlook MCP servers** the prompt depends on
   (`search_companies`, `get_company_info`, `outlook_calendar_search`, etc.) via
   `claude mcp add ...`, and confirm they load in print mode.

> **Resolved (was open issue #1a):** earlier notes claimed the claude.ai Affinity
> /Microsoft 365 connectors were *unavailable* in a headless `claude -p` run. That
> was a misdiagnosis. The connectors **do** load under `claude -p` (verify with
> `claude mcp list` — they show `✔ Connected`). The real cause of the
> "no briefing written" failures was the **permission mode**: `--permission-mode
> acceptEdits` auto-approves file edits but **not** MCP tool calls, and a
> non-interactive run has no human to approve them — so every `search_companies` /
> `outlook_calendar_search` call was silently *denied*. Claude then couldn't pull
> any data and replied with a clarifying question (the old log's *"I don't see any
> Affinity CRM integration…"* was Claude reacting to denied tools, not a missing
> server). `Run-DailyBriefing.ps1` now passes an explicit
> `--allowedTools "mcp__claude_ai_Affinity mcp__claude_ai_Microsoft_365"`, which
> fixes it without resorting to `bypassPermissions`.
>
> So in this step you only need to: (1) authenticate Claude, and (2) confirm both
> connectors show `✔ Connected` in `claude mcp list`. If the connector display
> names differ on this machine, update the two `mcp__…` ids in the script's
> `$mcpAllow` to match.

---

## Step 7 — Sideload the add-in into the new Outlook profile

Sideloading is a **one-time** action per profile (it persists afterward):

```powershell
npm start
```

This trusts the manifest and loads the add-in into Outlook on Windows desktop.
The "Daily Briefing" button appears on the ribbon in the mail read view; clicking
it opens the task pane.

Notes:
- `npm start` now launches `server.js` as the dev server (port 3000) and
  sideloads — so the pane has something to talk to during setup.
- For **new Outlook / Outlook on the web**, sideload by uploading
  `manifest.json` via *Get Add-ins → My add-ins → Add a custom add-in → Add from
  file* instead of `npm start`.
- The manifest `id` (GUID) can stay the same on a separate device. Only change
  it if the **same Microsoft 365 account** must load both the old and new copies
  at once — see the appendix.

---

## Step 8 — Register the scheduled tasks

This installs two tasks (bound to the current user via `$env:USERNAME`):

```powershell
npm run install-tasks
```

- **"HCP Daily Investor Briefing"** — at logon, runs the generator once per day.
- **"HCP Outlook Addin Server"** — at logon, starts `server.js` so the pane works
  without manually running `npm run server`.

If `Register-ScheduledTask` fails with an access error, re-run the command from
an **elevated** PowerShell. Rename the tasks by passing `-BriefingTask` /
`-ServerTask` to `Install-Tasks.ps1` if you want different names.

---

## Step 9 — First-run verification

1. **Server:** `npm run server`, then open `https://localhost:3000/taskpane.html`
   in a browser. You should get the pane (it will say "No briefing for today yet"
   until Step 9.2 succeeds — that's expected).
2. **Generate a briefing now:** `npm run briefing:force`
   - Check `logs\run-<today>.log` — it should end with `exit=0` **and** a
     `briefing-<today>.md` file should appear in `briefings\`.
   - If the log shows a clarifying-question reply or "no briefing was written"
     (`exit=3`), check the captured output: if Claude says it "lacks access" to the
     tools or asks you to authenticate, the MCP tool calls are being **denied**, not
     the servers missing — confirm the `$mcpAllow` ids in `Run-DailyBriefing.ps1`
     match `claude mcp list` (see Step 6). A clarifying reply with no tool attempts
     instead points to a truncated prompt.
3. **End to end:** with the server running and a briefing generated, open the
   task pane in Outlook — today's briefing should render.
4. **Reboot test:** log out and back in; confirm both scheduled tasks fire (the
   briefing log gets a new entry, and the pane loads without manually starting
   the server).

---

## Troubleshooting (by symptom)

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Pane: "Couldn't reach the briefing server" | `server.js` not running / cert not trusted | `npm run server`; redo Step 5 |
| Pane: "No briefing for today yet" | generator hasn't run or wrote to the wrong folder | run `npm run briefing:force`; recheck Step 3 paths all match |
| Log ends `exit=3` / clarifying question | MCP tool calls denied (not missing): `acceptEdits` doesn't allow MCP tools | ensure `--allowedTools $mcpAllow` is present and the ids match `claude mcp list` (Step 6) |
| Log shows garbled / cut-off prompt | older script version | ensure `Run-DailyBriefing.ps1` pipes the prompt via stdin (already fixed in this repo) |
| Briefing generated but pane 404s | folder path vs server mismatch | the generator's output path must equal `<server.js folder>\briefings` (Step 3) |

---

## Appendix — generating a fresh manifest GUID (optional)

Only needed if one Microsoft 365 account must run two copies simultaneously.
Replace the `"id"` value in `manifest.json` with a new GUID:

```powershell
[guid]::NewGuid().ToString()
```

Then re-validate: `npm run validate`.

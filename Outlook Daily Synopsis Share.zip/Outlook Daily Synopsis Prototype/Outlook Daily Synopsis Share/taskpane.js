Office.onReady(() => {
  const now = new Date();
  document.getElementById("weekday").textContent = now.toLocaleDateString(undefined, { weekday: "long" });
  document.getElementById("date").textContent = now.toLocaleDateString(undefined, { month: "long", day: "numeric" });

  fetchBriefing();
});

function show(sectionId) {
  ["loading", "error", "briefing-content"].forEach(id => {
    document.getElementById(id).hidden = id !== sectionId;
  });
}

function fetchBriefing() {
  // Abort the request if the server doesn't respond, so the pane doesn't sit on
  // "Loading…" forever when server.js isn't running.
  const TIMEOUT_MS = 10000;
  const controller = new AbortController();
  const timer = setTimeout(function () { controller.abort(); }, TIMEOUT_MS);

  fetch("https://localhost:3000/api/briefing", { signal: controller.signal })
    .then(function (res) {
      return res.json().then(function (data) {
        if (!res.ok) throw new Error(data.error || "HTTP " + res.status);
        return data;
      });
    })
    .then(function (data) {
      const container = document.getElementById("briefing-content");
      // marked renders the briefing markdown to HTML; DOMPurify strips any unsafe
      // markup before it reaches innerHTML. The briefing text originates from CRM
      // notes via an LLM, so it's treated as untrusted input.
      container.innerHTML = DOMPurify.sanitize(marked.parse(data.markdown));
      show("briefing-content");
    })
    .catch(function (err) {
      // AbortError (timeout) and TypeError (network/refused) both mean we never
      // reached the server; show a hint instead of a cryptic message.
      const isConnError = err.name === "AbortError" || err instanceof TypeError;
      document.getElementById("errorText").textContent = isConnError
        ? "Couldn't reach the briefing server. Make sure it's running at https://localhost:3000 (npm run server)."
        : err.message;
      show("error");
    })
    .finally(function () {
      clearTimeout(timer);
    });
}

# Daily Investor Briefing — Morning Run (Affinity-Only)

You are preparing Michael Lackey's (HCP) morning briefing for today's meetings.

**Source rule:** Use ONLY data from Michael's Affinity CRM (mlackey@hcp.com). Do NOT use WebSearch, WebFetch, or any external web research. If a fact isn't in Affinity, write "Not captured in Affinity" rather than back-filling from the web.

Today's date is whatever date the run executes on — use the current date for all calendar queries and the output filename.

## Step 1 — Pull today's external meetings

Use the Outlook MCP `outlook_calendar_search` tool to retrieve all calendar events between 00:00 and 23:59 local time today.

Filter the results to keep:
- Events with at least one attendee whose email domain is **not** `hcp.com` (true external meetings)
- Self-organized events where the **subject is a company name or domain** (e.g. "sentra.app", "Acme AI") — these are prep blocks Michael uses to research a specific company, and he wants a brief on them too

Drop:
- Internal-only meetings (all attendees @hcp.com) that don't match the "subject is a company" rule
- Focus blocks, holds, OOO, lunch, "no meetings" blocks, personal blocks that aren't tied to a specific company

For each kept meeting, extract:
- Start time
- Meeting title
- Company name (from attendee domain or meeting subject)
- External attendees (name + email) if any
- Whether it's a real external meeting or a self-block (prep slot)

If zero qualifying meetings, write a one-line briefing ("No meetings to brief on today") and skip to Step 3.

## Step 2 — Pull each company from Affinity (in parallel)

For each company on the kept list, run these Affinity MCP calls **in parallel**:

1. `search_companies(term=<domain or name>)` to resolve the company_id. If empty, try `semantic_search(prompt=<name>, limit=5)` as fallback.
2. Once you have `company_id`, run in parallel:
   - `get_company_info(company_id)` — pulls all field data (description, location, enriched fields, relationship-intelligence)
   - `get_company_list_entries(company_id)` — which Affinity lists the company is on (deal stage, pipeline membership)
   - `get_notes_for_entity(entity_id=company_id, entity_type=1)` — all notes attached to the company
   - `get_meetings_for_entity(entity_id=company_id, entity_type=1, start_time=<2 years ago>, end_time=<today>)` — meeting history

3. For each meeting returned, if it has interesting content, fetch the transcript fragments via `get_transcript_fragments` for context.

## Step 3 — Render the briefing

For each company, populate the six standard sections **using Affinity data only**:

1. **Team** — people captured in Affinity for this company (founders, key contacts). Pull from `get_company_info` field data and from people mentioned in notes. If none, "Not captured in Affinity".
2. **Product** — synthesize from Affinity company description + notes that describe what they do. Quote relevant lines from notes.
3. **Market** — synthesize from Affinity notes that touch on market size, growth, tailwinds. If absent, "Not captured in Affinity".
4. **Competitors** — synthesize from Affinity notes that mention competitors or alternatives. If absent, "Not captured in Affinity".
5. **Fundraise history** — synthesize from Affinity notes and any fundraise-related fields. Round, date, amount, lead, post-money where mentioned. If absent, "Not captured in Affinity".
6. **Affinity notes** —
   - Deal stage / list membership (from `get_company_list_entries`)
   - Internal owner / point person if captured
   - Last touchpoint date (from meetings or last note)
   - 2-3 bullet takeaways from the most recent notes (cite note dates)
   - Last meeting summary if available (cite meeting date)

If the company is not in Affinity, write **"Not in Affinity — net-new intro"** for the whole company block. List any external attendees so Michael walks in knowing the names. Do not fill from the web.

Write the briefing to `C:\Users\YangAndy\Outlook Daily Synopsis\briefings\briefing-YYYY-MM-DD.md` (create the `briefings` folder if it doesn't exist). Use this structure:

```
# Daily Briefing — {Weekday, Month D, YYYY}

You have {N} meetings to brief on today.

## Today at a glance

| Time | Company | Type | Attendees |
|------|---------|------|-----------|
| 9:00 AM | Acme AI | First meeting | Jane Doe (CEO), John Smith (CTO) |
| ... | ... | ... | ... |

(For self-blocks, use Type = "Self-block / prep")

---

## {Time} — {Company name}

**Attendees:** ... (or "Self-block — prep slot" if no external attendees)
**Meeting:** {title from calendar}

### Team
...

### Product
...

### Market
...

### Competitors
...

### Fundraise history
...

### Affinity notes
**Stage:** ...
**Owner:** ...
**Last touchpoint:** ...
- Recent note ({date}): ...
- Recent note ({date}): ...
- Last meeting ({date}): ...

---

(repeat per meeting in chronological order)
```

## Output

Print a one-line summary to stdout: `Briefing written for YYYY-MM-DD: N companies (A, B, C)`. Nothing else.

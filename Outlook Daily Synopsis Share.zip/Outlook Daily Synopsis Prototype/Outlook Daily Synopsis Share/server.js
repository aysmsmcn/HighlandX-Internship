const express = require("express");
const https = require("https");
const fs = require("fs");
const path = require("path");
const devCerts = require("office-addin-dev-certs");

const PORT = 3000;
const app = express();

app.use(express.static(__dirname));

// Builds a local-time YYYY-MM-DD stamp. Must match the generator script's
// (Get-Date).ToString('yyyy-MM-dd'), which is local time — using UTC here
// (e.g. toISOString) makes the server ask for a date the script never wrote
// around midnight/morning, producing a spurious 404.
function localDateStamp() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// Serves today's briefing markdown for the task pane.
// A single async read (rather than existsSync + readFileSync) avoids the
// time-of-check/time-of-use race and never blocks the event loop: ENOENT means
// the briefing simply isn't there yet (404); anything else is a real error (500).
app.get("/api/briefing", (req, res) => {
  const stamp = localDateStamp();
  const file = path.join(__dirname, "briefings", `briefing-${stamp}.md`);
  fs.readFile(file, "utf8", (err, markdown) => {
    if (err) {
      if (err.code === "ENOENT") {
        return res.status(404).json({ error: "No briefing for today yet. Run the briefing script first." });
      }
      console.error("Failed to read briefing file:", err);
      return res.status(500).json({ error: "Could not read today's briefing." });
    }
    res.json({ markdown });
  });
});

(async () => {
  try {
    const options = await devCerts.getHttpsServerOptions();
    https.createServer(options, app).listen(PORT, () => {
      console.log(`Reminder add-in running at https://localhost:${PORT}`);
    });
  } catch (err) {
    console.error("Could not start HTTPS server. Install the dev certificates first with: npx office-addin-dev-certs install");
    console.error(err);
    process.exit(1);
  }
})();

[CmdletBinding()]
param(
    [string]$AddinRoot = "C:\Users\YangAndy\Outlook Daily Synopsis",
    [switch]$Force
)

$ErrorActionPreference = 'Continue'

$logDir = Join-Path $AddinRoot 'logs'
if (-not (Test-Path -LiteralPath $logDir)) {
    New-Item -ItemType Directory -Path $logDir | Out-Null
}

$briefingsDir = Join-Path $AddinRoot 'briefings'
if (-not (Test-Path -LiteralPath $briefingsDir)) {
    New-Item -ItemType Directory -Path $briefingsDir | Out-Null
}

$stamp   = (Get-Date).ToString('yyyy-MM-dd')
$logFile = Join-Path $logDir "run-$stamp.log"

# Skip if today's briefing already exists (unless -Force). Lets the at-logon
# trigger fire on every login without re-running Claude more than once a day.
$briefingFile = Join-Path $briefingsDir "briefing-$stamp.md"
if ((Test-Path -LiteralPath $briefingFile) -and -not $Force) {
    "Briefing for $stamp already exists; skipping (use -Force to regenerate)." | Out-File -FilePath $logFile -Encoding utf8 -Append
    Write-Host "Briefing for $stamp already exists; skipping (use -Force to regenerate)."
    exit 0
}

"=== Run started $((Get-Date).ToString('s')) ===" | Out-File -FilePath $logFile -Encoding utf8 -Append

$promptFile = Join-Path $AddinRoot 'daily-brief.md'
if (-not (Test-Path -LiteralPath $promptFile)) {
    "ERROR: prompt file missing at $promptFile" | Out-File -FilePath $logFile -Encoding utf8 -Append
    exit 1
}

$prompt = Get-Content -LiteralPath $promptFile -Raw -Encoding UTF8

$claude = (Get-Command claude -ErrorAction SilentlyContinue).Source
if (-not $claude) {
    "ERROR: 'claude' CLI not found on PATH. Install Claude Code or fix PATH." | Out-File -FilePath $logFile -Encoding utf8 -Append
    exit 2
}

# Pass the prompt over stdin rather than as a command-line argument. Windows
# PowerShell 5.1 mangles native-command arguments that contain double quotes,
# which previously truncated the prompt at the first " (daily-brief.md's
# `write "Not captured in Affinity"`) so Claude only ever saw a fragment and
# replied that the message was cut off.
#
# Force UTF-8 on both halves of the pipe so non-ASCII (em-dashes, smart quotes)
# survives and the captured output isn't corrupted:
#   $OutputEncoding          -> encoding used when piping text to claude's stdin
#   [Console]::OutputEncoding -> encoding used to decode claude's stdout
# (The original log's "Y o u r  m e s s a g e" garbling came from a UTF-16
# mismatch on this boundary.)
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# MCP tool allow-list. --permission-mode acceptEdits auto-approves FILE EDITS only;
# it does NOT auto-approve MCP tool calls. In a non-interactive `claude -p` run there
# is no human to approve them, so without an explicit allow-list every Affinity/Outlook
# tool call is auto-DENIED -- Claude then can't pull any calendar/CRM data and replies
# with a clarifying question, writing no briefing. (This is the real cause of the
# "no briefing written" failures the logs previously misattributed to the MCP servers
# being unavailable headless: `claude mcp list` shows them Connected and they DO load
# under `claude -p` -- they were just being denied.) We allow exactly the two data
# connectors the prompt needs, named by their headless server ids. These are
# server-scoped wildcards (all tools on the server), NOT bypassPermissions, so the
# blast radius stays limited to these two connectors plus auto-approved file edits --
# no Bash or arbitrary tools. If the connectors are renamed in Claude, update these to
# match the ids shown by `claude --print --allowedTools ... ` / the mcp__<server>__ ids.
$mcpAllow = 'mcp__claude_ai_Affinity mcp__claude_ai_Microsoft_365'

# SECURITY NOTE: this runs Claude unattended with --permission-mode acceptEdits,
# so file edits are auto-approved with no human in the loop. This is required for
# headless generation (Claude must write the briefing file without prompting), but
# it means the blast radius is whatever the session can touch. It is intentionally
# constrained by: (1) running from $AddinRoot as the working directory, (2) the
# scheduled task running as a Limited (non-elevated) principal -- see Install-Tasks.ps1,
# and (3) the scoped --allowedTools above. Do not raise this to bypassPermissions or
# run the task elevated.
Push-Location -LiteralPath $AddinRoot
try {
    # Tee-Object -Variable streams output to the console (handy for manual runs)
    # AND captures it, so we can append it to the log with explicit UTF-8.
    # Tee-Object -FilePath would write UTF-16LE on PS 5.1, which is what corrupted
    # the log before; routing through Out-File keeps every log write UTF-8.
    $prompt | & $claude -p --permission-mode acceptEdits --allowedTools $mcpAllow 2>&1 | Tee-Object -Variable claudeOutput
    $exit = $LASTEXITCODE
    $claudeOutput | Out-File -FilePath $logFile -Encoding utf8 -Append
} finally {
    Pop-Location
}

# Verify the run actually produced a briefing. Claude exits 0 even when it only
# replies with a clarifying question (e.g. missing Affinity MCP), so the exit
# code alone can't be trusted — the briefing file's existence is the real signal.
$briefingWritten = (Test-Path -LiteralPath $briefingFile) -and ((Get-Item -LiteralPath $briefingFile).Length -gt 0)
if (-not $briefingWritten) {
    "ERROR: no briefing was written to $briefingFile (claude exit=$exit). The run produced no output file. Check the captured output above: if Claude says it 'lacks access' to the Affinity/Outlook tools or asks you to authenticate, the cause is almost certainly the MCP tool calls being denied -- confirm the --allowedTools server ids above still match `claude mcp list` (the servers loading is necessary but NOT sufficient; their tools must also be allowed). A clarifying-question reply with no tool attempts usually means a truncated/garbled prompt instead." | Out-File -FilePath $logFile -Encoding utf8 -Append
    Write-Host "Briefing FAILED -- no file written. See $logFile" -ForegroundColor Red
    if ($exit -eq 0) { $exit = 3 }  # don't let a falsely-zero exit code mask the failure
}

"=== Run finished $((Get-Date).ToString('s')) exit=$exit ===" | Out-File -FilePath $logFile -Encoding utf8 -Append
exit $exit

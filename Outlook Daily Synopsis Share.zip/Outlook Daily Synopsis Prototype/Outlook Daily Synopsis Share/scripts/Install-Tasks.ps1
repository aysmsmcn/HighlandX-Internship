[CmdletBinding()]
param(
    [string]$AddinRoot      = "C:\Users\YangAndy\Outlook Daily Synopsis",
    [string]$BriefingTask   = 'HCP Daily Investor Briefing',
    [string]$ServerTask     = 'HCP Outlook Addin Server'
)
$ErrorActionPreference = 'Stop'
Write-Host "=== Outlook Daily Synopsis --- task installer ===" -ForegroundColor Cyan

# 1. Verify prerequisites
Write-Host "Checking prerequisites..." -ForegroundColor Yellow

$runner    = Join-Path $AddinRoot 'scripts\Run-DailyBriefing.ps1'
$prompt    = Join-Path $AddinRoot 'daily-brief.md'
$serverJs  = Join-Path $AddinRoot 'server.js'

foreach ($p in @($runner, $prompt, $serverJs)) {
    if (-not (Test-Path -LiteralPath $p)) { throw "Missing file: $p" }
    Write-Host "  ok  $p"
}

$claude = (Get-Command claude -ErrorAction SilentlyContinue).Source
if (-not $claude) { throw "'claude' CLI not on PATH. Install Claude Code first, then re-run." }
Write-Host "  ok  claude at $claude"

$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { throw "'node' not on PATH. Install Node.js first, then re-run." }
Write-Host "  ok  node at $node"

$principal = New-ScheduledTaskPrincipal `
    -UserId $env:USERNAME `
    -LogonType Interactive `
    -RunLevel Limited

# 2. Briefing generation task — at every logon (skips if today's already exists)
Write-Host ""
Write-Host "Registering '$BriefingTask' (at logon)..." -ForegroundColor Yellow
$briefingAction = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$runner`" -AddinRoot `"$AddinRoot`""
$briefingTrigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$briefingSettings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
Register-ScheduledTask `
    -TaskName $BriefingTask `
    -Action $briefingAction `
    -Trigger $briefingTrigger `
    -Settings $briefingSettings `
    -Principal $principal `
    -Description 'Generates the daily investor briefing markdown file for the Outlook add-in.' `
    -Force | Out-Null
Write-Host "  ok  '$BriefingTask' registered" -ForegroundColor Green

# 3. Add-in server task — on login
Write-Host ""
Write-Host "Registering '$ServerTask' (at login)..." -ForegroundColor Yellow
$serverAction = New-ScheduledTaskAction `
    -Execute $node `
    -Argument "`"$serverJs`"" `
    -WorkingDirectory $AddinRoot
$serverTrigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
# ExecutionTimeLimit of zero means "no time limit" to Task Scheduler -- the server
# is long-running and must not be killed after the default 3 days.
$serverSettings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask `
    -TaskName $ServerTask `
    -Action $serverAction `
    -Trigger $serverTrigger `
    -Settings $serverSettings `
    -Principal $principal `
    -Description 'Serves the Outlook Daily Synopsis add-in over HTTPS at localhost:3000.' `
    -Force | Out-Null
Write-Host "  ok  '$ServerTask' registered" -ForegroundColor Green

Write-Host ""
Write-Host "Installation complete." -ForegroundColor Cyan
Write-Host "  Briefing : at every login (once per day) -> $AddinRoot\briefings\"
Write-Host "  Server   : starts at every login -> https://localhost:3000"
Write-Host ""
Write-Host "Dry-run the briefing now:"
Write-Host "  npm run briefing   (from $AddinRoot)"
